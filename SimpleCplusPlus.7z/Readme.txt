Welcome!

THis is Simple C++. A (revolutionary) library (or a header file) That will make everyone love C++. This was just Made in 2 days(or 2 nights).

It has limitations. So please wait until a new version comes out :)

BE CAREFUL WHILE USING THIS!!!!!

And I (@float_3.14 on youtube) am not responsibe if someone creates a virus using my header file.

Look at source code for tutorials. Video Tutorial Coming soon!

This library contains GPL. Link is in the src file (scpp.h) if you wish to read it :)